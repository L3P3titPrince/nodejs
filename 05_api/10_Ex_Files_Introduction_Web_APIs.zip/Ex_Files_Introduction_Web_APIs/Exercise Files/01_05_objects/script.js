var car = {
   make: "Honda",
   model: "Fit",
   year: 2012,
   honk: function() { alert("Beep beep"); },
   driver: { name: "Andrew", license: "CA" }
}
console.log(car.make);
console.log(car.driver.name);